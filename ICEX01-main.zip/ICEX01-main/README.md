# SE-Team-6

**Team Name:** Team 6

**Team Goal:** Our team goal is to learn how to manage a software engineering project and become the best software engineers that we can be!

**Team Members:** Nathan Barrett, Cole Evans, Shivali Mate, Samir Sanyal, Saai Vignesh P

**Team Experience:**

- **Programming Languages:** C#, CSS, SCSS, HTML, Java, Python, SQL, C/C++, Powershell, Bash, JavaScript, TypeScript, R, Kotlin

- **Technologies:** VS Code, IntelliJ, Github, PuTTY, AWS, Azure, Google Cloud, Kubernetes, MySQL, PostgreSQL, MongoDB, Django, Android Studio, Firebase

- **Previous Projects:**
  - Owned and operated a Java based videogame server network.
  - Developed multiple Java plugins for a videogame server.
  - LAPD Crime Detection project.
  - Document Summarization LLM.
  - MEAN/PERN stack web apps.
  - CNN-based multi-class image classifiers using TensorFlow/Keras.
  - Data Product Catalog Marketplace

**Team Communication Mechanism:** Discord, E-mail

How, when, and where will the team meet and with what frequency?

- The team will meet thrice a week: two in-person meetings after lectures and one online meeting.

- Our team has mainly been communicating through Discord and email. We plan on meeting three times a week and have multiple outlets to accomplish this such as Zoom, Discord, or an in person meeting on campus.

How will the team share information?

- The team will communicate and share information through the Discord server or the Microsoft Teams group that has been set up.

- Our team will share information through Discord, email, or in person discussions whenever needed.

How will the team know who is working on what?

- The team will discuss responsibilities during stand-up calls and maintain consistent communication through the selected platforms.

- We will clearly define who is working on what and can write out certain roles and responsibilities so that we can remain organized.

Where will the team store information about the team and the project?

- GitHub will be our primary location for storing anything code related. As for other documents or files, we will create a team OneDrive or Google Drive folder.

**Team Decision Process:**

How will the team make decisions? Provide details so for instance if by majority vote, how will the vote be defined, when will the vote happen and how will it be recorded? Etc.

- Votes will be conducted either during meetings or through polls on Discord or Microsoft Teams.

- Votes and decisions will be documented in meeting notes or as messages.

- For making decisions the team will get together and brainstorm towards a solution, which we will eventually vote upon. If we cannot come to a solution that the majority agree upon, we will ensure that everything is well thought out and explained until we can decide.

**Team Contact:**

How does an external party communicate with the team?

- External parties can reach the team via email or Microsoft Teams

**Per team member:**

**Name:**
Shivali Mate

**Contact Info:**
shimate@iu.edu

**Experience:**

- Programming Languages:
  Python, Java, SQL, HTML, CSS, JavaScript
- Technologies:
  Django, Flask, PostgreSQL, PowerBI
- Previous Projects:
  1. Data Product Catalog Marketplace: Led a team to develop a centralized platform for managing and accessing data products efficiently.
  2. Sign Language Recognition using Hand Gestures: Developed a machine learning model for recognizing sign language, integrating it with a real-time interface.

**Class year:**
Graduate MSCS 1st year

**Career Interests:**
Get a Good Internship for Summer 2025

**Personal Interests or hobbies:**
Volleyball, Dancing

**A movie or book the member would recommend:**
Bhool Bhulaiyaa

**Member's most impactful weakness:**
Communication

**Member's Biggest strength:**
Quick Learner

<br>

**Name:** Samir Sanyal

**Contact Info:** sasanyal@iu.edu 9309043450

**Experience:** 3+ years of work experience as Cloud Engineer

**Programming Languages:** Python, C/C++, SQL, Powershell, JavaScript, R

**Technologies:** AWS, Azure, Kubernetes, Postgres, MSSQL, Docker, Linux

**Previous Projects:** LAPD Crime Detection project Analyze crime patterns by location, time, and type of crime, identifying hotspots using LAT and LON, classifying crimes by severity or type and studying demographic patterns of victims

**Class year:** MSCS 1st Year

**Career Interests:** Get summer internship

**Personal Interests or hobbies:** anime, gaming

**A movie or book the member would recommend:** Castlevania

**Member's most impactful weakness:** Self criticism

**Member's Biggest strength:** Adaptiveness

<br>

**Name:** Nathan Barrett

**Contact Info:** nwbarret@iu.edu

**Experience:**

- **Programming Languages:** C#, CSS, HTML, Java, Python, SQL

- **Technologies:** VS Code, IntelliJ, Github, PuTTY

- **Previous Projects:**
  - Owned and operated a Java based videogame server network.
  - Developed multiple Java plugins for a videogame server.

**Class year:** Senior

**Career Interests:** Fullstack Web Development, Entrepreneurship, Any Technology Profession in the Golf or Video Game industries.

**Personal Interests or hobbies:** Golf, Video Games, Entrepreneurship

**A movie or book the member would recommend:** La La Land

**Member's most impactful weakness:** I am not the most experienced programmer and software engineer and am still learning many skills so I may be slow on those fronts (minoring in Comp Sci).

**Member's Biggest strength:** I am a good leader and facilitator and will do my best to help the team work effectively.

<br>

**Name:** Saai Vignesh Premanand

**Contact Info:** saprem@iu.edu

**Experience:** 3+ years of work experience as a Full-Stack Software Engineer

**Programming Languages:** Python, SQL, HTML, CSS, SCSS, JavaScript, TypeScript, Bash

**Technologies:** AWS, Google Cloud, PostgreSQL, MongoDB, MySQL, Git, Docker

**Previous Projects:**

- Developed Conversation Document Summarization Bot using LLM (Hackathon)
- Worked on MEAN/PERN full-stack web application projects (Previous Full-time)
- Plant Disease, Chest X-Ray Classifiers using TensorFlow and Keras (Personal Projects)

**Class year:** Graduate 1st Year

**Career Interests:** Data Science, Full-Stack Web Development, Start a Startup

**Personal Interests or hobbies:** Coding, Music, Mentoring, Traveling

**A movie or book the member would recommend:** I'm not much into books or movies.

**Member's most impactful weakness:** Procrastination, trying my best to overcome it.

**Member's Biggest strength:** I am a good leader and team player and can work well with others.

<br>

**Name:** Cole Evans

**Contact Info:** ce9@iu.edu

**Experience:**

**Programming Languages:** Java, Kotlin, HTML, CSS

**Technologies:** VSCode, IntelliJ, Github, Firebase, Android Studio

**Previous Projects:**

- Full Stack flower-ordering service with Java backend and HTML/CSS frontend
- Restaurant-ordering app using Kotlin (like DoorDash)
- Word Search algorithm using Java

**Class year:** Junior

**Career Interests:** Software Engineering

**Personal Interests or hobbies:** Weightlifting, Movies, Baseball, Basketball

**A movie or book the member would recommend:** Memento

**Member's most impactful weakness:** Organization, if I leave things unchecked it can be a problem but I am working on staying more focused and keeping harder schedules.

**Member's Biggest strength:** I am always willing to learn and receive criticism to better my work.
