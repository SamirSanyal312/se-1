# Monster File Editor (MFE)

The **Monster File Editor (MFE)** is a Python-based command-line tool designed to allow users to edit monster attributes in the Angband game. This tool reads and modifies the `monster.txt` file, enabling users to customize monsters and enhance their gameplay experience.

## Features
- Edit monster attributes such as name, speed, hit-points, experience, blows, flags, and more.
- Save edited monsters to a new `monster.txt` file.
- Supports user-friendly navigation through monster categories and search functionality.
- Ensures valid input for game-compatible values.

## Installation & Usage
Clone the repository:

    $ git clone git@github.iu.edu:SE-Team-6/MFE-Editor.git

Navigate to the project directory:

    $ cd MFE-Editor

Run the program using the following, specifying Angband's gamedata directory:

    $ python app.py /path/to/angband/gamedata

Run the test cases using the following, specifying MFE directory path in test_cases file:

    $ python -m unittest -v test.test_cases


## Other Details
To Do

## Documentation
See the man page `MFE.1` for full usage instructions.
