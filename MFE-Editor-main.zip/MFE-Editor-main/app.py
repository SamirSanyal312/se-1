'''
    Angband Monster File Editor (MFE)
    Version 1.0.0
    Author: SE-Team-6
'''

import sys
from include.editor import MonsterFileEditor


def main():
    """
    Main function to handle command-line arguments and start the program.
    """
    if __name__ == "__main__":
        if len(sys.argv) != 2:
            print("\nUsage:\npython app.py <path-to-angband-gamedata-dir>\n")
            sys.exit(1)
        
        gamedata_path = sys.argv[1]
        editor = MonsterFileEditor(gamedata_path)
        editor.run()

# Run the main function
main()