import os
from include.parser import MonsterFileParser


class MonsterFileEditor:
    def __init__(self, gamedata_path):
        self.gamedata_path = gamedata_path
        self.clear_screen()
        self.print_intro()

    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def print_intro(self):
        with open("art.txt") as f:
            print(f.read())

    def run(self):
        mf_parser = MonsterFileParser(self.gamedata_path)
        monsters = mf_parser.get_monsters()
        blow_methods = mf_parser.get_blow_methods()
        blow_effects = mf_parser.get_blow_effects()

        print(f"{len(monsters)} monsters read from file.")
        print(f"{len(blow_methods)} blow methods read from file.")
        print(f"{len(blow_effects)} blow effects read from file.\n")

        while True:
            print("Menu Options:")
            print("1. List Monsters")
            print("2. View Monster Attributes")
            print("3. View-Only Monster List")
            print("4. Edit and Save Monsters")
            print("5. List Monster Categories")
            print("6. Exit")
            choice = input("Enter your choice: ")

            if choice == '1':
                self.list_monsters(monsters)
            elif choice == '2':
                self.view_monster_attributes(monsters)
            elif choice == '3':
                self.view_only_monster_list(monsters)
            elif choice == '4':
                self.edit_monsters(monsters, mf_parser)
            elif choice == '5':
                self.list_monster_categories(monsters)
            elif choice == '6':
                print("Exiting the Monster File Editor.")
                break
            else:
                print("Invalid choice. Try again.\n")

    # ✅ New minimal addition for categories:
    def list_monster_categories(self, monsters):
        categories = {}
        for monster in monsters:
            category = monster.base if monster.base else "Unknown"
            categories.setdefault(category, []).append(monster.name)

        if not categories:
            print("No categories found.\n")
            return

        category_list = list(categories.keys())
        print("\nMonster Categories:")
        for idx, category in enumerate(category_list, start=1):
            print(f"{idx}. {category}")

        try:
            selected_idx = int(input("\nEnter the category number to list monsters: "))
            if selected_idx < 1 or selected_idx > len(category_list):
                print("Invalid category number.\n")
                return
            selected_category = category_list[selected_idx - 1]
            print(f"\nMonsters in '{selected_category}' category:")
            for name in categories[selected_category]:
                print(f"- {name}")
            print()
        except ValueError:
            print("Invalid input. Please enter a number.\n")

    # 🔹 Your existing methods below remain untouched
    def list_monsters(self, monsters):
        for idx, monster in enumerate(monsters, start=1):
            print(f"{idx}. {monster.name}")
            if idx % 20 == 0:
                cont = input("Press Enter to continue or 'q' to quit listing: ")
                if cont.lower() == 'q':
                    break

    def view_monster_attributes(self, monsters):
        name = input("Enter monster name to view attributes: ").strip()
        monster = next((m for m in monsters if m.name.lower() == name.lower()), None)
        if monster:
            self.print_monster_attributes(monster)
        else:
            print("Monster not found.\n")

    def view_only_monster_list(self, monsters):
        self.list_monsters(monsters)

    def edit_monsters(self, monsters, mf_parser):

        # Existing edit logic here (unchanged)
        pass

        from .validator import MonsterFileValidator
        validator = MonsterFileValidator(monsters, mf_parser.get_blow_methods(), mf_parser.get_blow_effects())
        
        while True:
            name = input("Enter monster name to edit (or 'q' to quit): ").strip()
            if name.lower() == 'q':
                break
            monster = next((m for m in monsters if m.name.lower() == name.lower()), None)
            if monster:
                self.edit_monster_attributes(monster, mf_parser)
                print(f"{monster.name} updated.\n")
            else:
                print("Monster not found.\n")

        invalid_monsters = validator.validate_monsters()
        if invalid_monsters:
            print("The following monsters have validation issues and will not be saved:")
            for monster in invalid_monsters:
                print(f" - {monster.name}")
            return

        modified_path = os.path.join(self.gamedata_path, "monster_modified.txt")
        mf_parser.save_monsters(monsters, modified_path)
        print(f"Modified monsters saved to {modified_path}\n")

        replace = input("Do you want to replace the original monster.txt with the modified version? (yes/no): ").strip()
        if replace.lower() == 'yes':
            backup_path = os.path.join(self.gamedata_path, "monster_backup.txt")
            original_path = os.path.join(self.gamedata_path, "monster.txt")
            os.rename(original_path, backup_path)
            os.rename(modified_path, original_path)
            print(f"Backup of original monster.txt created at {backup_path}")
            print("Original monster.txt has been successfully replaced with the modified version.\n")
        else:
            print("Original monster.txt not replaced.\n")

    def edit_monster_attributes(self, monster, mf_parser):
        monster.name = input(f"Name [{monster.name}]: ") or monster.name
        monster.speed = int(input(f"Speed [{monster.speed}]: ") or monster.speed)
        monster.hit_points = int(input(f"Hit Points [{monster.hit_points}]: ") or monster.hit_points)
        monster.experience = int(input(f"Experience [{monster.experience}]: ") or monster.experience)
        monster.description = input(f"Description [{monster.description}]: ") or monster.description
        monster.light = int(input(f"Light [{monster.light}]: ") or monster.light)
        monster.depth = int(input(f"Depth [{monster.depth}]: ") or monster.depth)

        # Edit blows
        monster.blows = []
        for i in range(4):
            blow_input = input(f"Blow {i+1} (method:effect:damage) or leave blank to skip: ").strip()
            if blow_input:
                parts = blow_input.split(':')
                blow = {
                    'method': parts[0].strip() if len(parts) > 0 else '',
                    'effect': parts[1].strip() if len(parts) > 1 else '',
                    'damage': parts[2].strip() if len(parts) > 2 else ''
                }
                if mf_parser.blow_methods and blow['method'] not in mf_parser.blow_methods:
                    print(f"Invalid blow method: {blow['method']}")
                    continue
                if blow['effect'] and blow['effect'] not in mf_parser.blow_effects:
                    print(f"Invalid blow effect: {blow['effect']}")
                    continue
                monster.blows.append(blow)

        # Edit flags
        monster.flags = set(input(f"Flags (separated by |) [{ ' | '.join(monster.flags) }]: ").split('|'))
        monster.flags_off = set(input(f"Flags-Off (separated by |) [{ ' | '.join(monster.flags_off) }]: ").split('|'))


    def print_monster_attributes(self, monster):
        print(f"Name: {monster.name}")
        print(f"Speed: {monster.speed}")
        print(f"Hit Points: {monster.hit_points}")
        print(f"Experience: {monster.experience}")
        print(f"Blows: {monster.blows}")
        print(f"Flags: {monster.flags}")
        print(f"Flags-Off: {monster.flags_off}")
        print(f"Description: {monster.description}")
        print(f"Light: {monster.light}")
        print(f"Depth: {monster.depth}")
        print(f"Base: {monster.base}\n")
