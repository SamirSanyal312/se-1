class Monster:
    # def __init__(self):
    def __init__(self, name=None, speed=None, hit_points=None, experience=None, blows=None, flags=None, 
            flags_off=None, description=None, light=None, depth=None, shape=None):
        self.name = ""
        self.speed = 0
        self.hit_points = 0
        self.experience = 0
        self.blows = []  # List of dictionaries with method, effect, damage
        self.flags = set()
        self.flags_off = set()
        self.description = ""
        self.light = 0
        self.depth = 0
        self.shape = ""

        self.base = ""


    

    def __repr__(self):
        return f"Monster(name='{self.name}', speed={self.speed}, hit_points={self.hit_points}, base='{self.base}')"
