import os
from typing import List
from .monster import Monster


class MonsterFileParser:
    gamedata_path = ""
    monsters = []
    blow_methods = set()
    blow_effects = set()

    def __init__(self, gamedata_path: str):
        self.gamedata_path = gamedata_path
        monster_path = os.path.join(self.gamedata_path, "monster.txt")

        if not os.path.exists(monster_path):
            raise FileNotFoundError(
                f"Monster file not found at {monster_path}"
            )

        self.monsters = self.read_monsters(monster_path)

        related_data_parser = RelatedDataParser(self.gamedata_path)
        blow_methods, blow_effects = related_data_parser.get_related_data()
        self.blow_methods = blow_methods
        self.blow_effects = blow_effects

    def get_monsters(self):
        return self.monsters

    def get_blow_methods(self):
        return self.blow_methods

    def get_blow_effects(self):
        return self.blow_effects

    def read_monsters(self, monster_path: str):
        monsters = []
        current_monster = None

        with open(monster_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()

                if not line or line.startswith('#'):
                    continue

                if line.startswith('name:') and not line.endswith('<player>'):
                    if current_monster:
                        monsters.append(current_monster)
                    current_monster = Monster()
                    current_monster.name = line[5:].strip()
                elif current_monster and ':' in line:
                    attr, value = line.split(':', 1)
                    attr = attr.strip()
                    value = value.strip()

                    if attr == 'speed':
                        current_monster.speed = int(value)
                    elif attr == 'hit-points':
                        current_monster.hit_points = self._parse_hit_points(value)
                    elif attr == 'experience':
                        current_monster.experience = int(value)
                    elif attr == 'blow':
                        blow_parts = value.split(':')
                        blow_dict = {
                            'method': blow_parts[0].strip() if len(blow_parts) > 0 else '',
                            'effect': blow_parts[1].strip() if len(blow_parts) > 1 else '',
                            'damage': blow_parts[2].strip() if len(blow_parts) > 2 else ''
                        }
                        current_monster.blows.append(blow_dict)
                    elif attr == 'flags':
                        for flag in value.split('|'):
                            current_monster.flags.add(flag.strip())
                    elif attr == 'flags-off':
                        for flag in value.split('|'):
                            current_monster.flags_off.add(flag.strip())
                    elif attr == 'desc' or attr == 'description':
                        current_monster.description = value
                    elif attr == 'light':
                        current_monster.light = int(value)
                    elif attr == 'depth':
                        current_monster.depth = int(value)
                    elif attr == 'shape':
                        current_monster.shape = value
                    elif attr == 'base':
                        current_monster.base = value

        if current_monster:
            monsters.append(current_monster)

        return monsters

    def save_monsters(self, monsters: List[Monster], output_path: str):
        """
        Save the list of monsters back into a monster.txt-style file.
        """
        with open(output_path, 'w', encoding='utf-8') as f:
            for monster in monsters:
                f.write(f"name:{monster.name}\n")
                f.write(f"speed:{monster.speed}\n")
                f.write(f"hit-points:{monster.hit_points}\n")
                f.write(f"experience:{monster.experience}\n")

                for blow in monster.blows:
                    blow_str = blow['method']
                    if blow['effect']:
                        blow_str += f":{blow['effect']}"
                        if blow['damage']:
                            blow_str += f":{blow['damage']}"
                    f.write(f"blow:{blow_str}\n")

                if monster.flags:
                    f.write(f"flags:{' | '.join(monster.flags)}\n")

                if monster.flags_off:
                    f.write(f"flags-off:{' | '.join(monster.flags_off)}\n")

                if monster.description:
                    f.write(f"description:{monster.description}\n")

                if monster.light:
                    f.write(f"light:{monster.light}\n")

                f.write(f"depth:{monster.depth}\n")

                if monster.shape:
                    f.write(f"shape:{monster.shape}\n")

                if monster.base:
                    f.write(f"base:{monster.base}\n")

                f.write("\n")

    def _parse_hit_points(self, hp_str: str) -> int:
        if 'd' in hp_str:
            try:
                num_dice, dice_size = hp_str.split('d')
                return int(num_dice) * (int(dice_size) + 1) // 2
            except ValueError:
                return 0
        else:
            try:
                return int(hp_str)
            except ValueError:
                return 0


class RelatedDataParser:
    blow_methods = set()
    blow_effects = set()

    def __init__(self, gamedata_path: str):
        self.gamedata_path = gamedata_path

        blow_methods_path = os.path.join(self.gamedata_path, "blow_methods.txt")
        blow_effects_path = os.path.join(self.gamedata_path, "blow_effects.txt")

        self.blow_methods = self._read_blow_methods(blow_methods_path)
        self.blow_effects = self._read_blow_effects(blow_effects_path)

    def get_related_data(self):
        """
        Return read blow effects and blow methods.
        """
        return self.blow_methods, self.blow_effects

    def _read_blow_methods(self, file_path: str):
        blow_methods = set()
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.startswith('name:'):
                        blow_methods.add(line[5:].strip())
        return blow_methods

    def _read_blow_effects(self, file_path: str):
        blow_effects = set()
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.startswith('name:'):
                        blow_effects.add(line[5:].strip())
        return blow_effects
