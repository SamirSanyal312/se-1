import os
import re
from .editor import MonsterFileEditor

class MonsterFileValidator:
    def __init__(self, monsters, blow_methods, blow_effects):
        self.monsters = monsters
        self.blow_methods = blow_methods
        self.blow_effects = blow_effects

    def validate_monsters(self):
        """Validate all monsters in the list and return invalid monsters with reasons"""
        invalid_monsters = []
        for monster in self.monsters:
            if not self.validate_monster(monster):
                print(f"Invalid Monster: {monster.name}")
                print(monster.__dict__)  # Print monster attributes to see what might be wrong
                invalid_monsters.append(monster)

        return invalid_monsters

    
    def validate_monster(self, monster):
        """Validate a single monster's attributes"""
        if not monster.name or not isinstance(monster.name, str):
            print(f"{monster.name} failed: Invalid name")
            return False

        if not isinstance(monster.speed, int) or not (0 <= monster.speed <= 255):
            print(f"{monster.name} failed: Invalid speed ({monster.speed})")
            return False

        if not isinstance(monster.hit_points, int) or monster.hit_points <= 0:
            if hasattr(monster, "shape"):
                print(f"✅ {monster.name} is a shape-shifted form and does not need hit points.")
            else:
                print(f"❌ {monster.name} failed: Invalid hit points ({monster.hit_points})")
                return False

        if not isinstance(monster.experience, int) or monster.experience < 0:
            print(f"{monster.name} failed: Invalid experience ({monster.experience})")
            return False

        if not isinstance(monster.depth, int) or monster.depth < 0:
            print(f"{monster.name} failed: Invalid depth ({monster.depth})")
            return False

        # Filter out empty flags
        monster.flags = {flag for flag in monster.flags if flag.strip()}
        monster.flags_off = {flag for flag in monster.flags_off if flag.strip()}

        # Validate blows properly
        if not self.validate_blows(monster.blows):
            print(f"{monster.name} failed: Invalid blows {monster.blows}")
            return False

        return True


    def validate_blows(self, blows):
        """Ensure blows are in valid format and use valid methods/effects."""
        if len(blows) > 9:
            print("Blows failed: Too many blows")
            return False

        for blow in blows:
            method = blow.get('method', '').strip()
            effect = blow.get('effect', '').strip()
            damage = blow.get('damage', '').strip()

            # Allow method-only blows
            if not method:
                print(f"Invalid blow (missing method): {blow}")
                return False
            if method not in self.blow_methods:
                print(f"Invalid blow method: {method}")
                return False
            if effect and effect not in self.blow_effects:
                print(f"Invalid blow effect: {effect}")
                return False
            if damage and not self.is_valid_damage(damage):
                print(f"Invalid blow damage: {damage}")
                return False

        return True

    def is_valid_damage(self, damage):
        """Validate damage format (e.g., '1d1', '2d6', or empty)."""
        if not damage:
            return True  # Empty damage is allowed
        return bool(re.match(r'^\d+d\d+$', damage))  # Dice format (e.g., '2d6')
