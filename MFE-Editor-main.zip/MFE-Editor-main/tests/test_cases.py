import unittest
from unittest.mock import patch, MagicMock
import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../mfe_include')))

from include.parser import MonsterFileParser, RelatedDataParser
from include.monster import Monster
from include.validator import MonsterFileValidator
from include.editor import MonsterFileEditor

class TestMonsterFileParser(unittest.TestCase):

    def setUp(self):
        self.gamedata_path = r"/path/to/MFE"   # 🔔 Replace this with your actual path     
        self.parser = MonsterFileParser(self.gamedata_path)        
        
    @patch("os.path.exists")
    @patch("builtins.open", new_callable=MagicMock)
    def test_read_monsters_valid_file(self, mock_open, mock_exists):
        mock_exists.return_value = True
        mock_open.return_value.__enter__.return_value = [
            "name:hippogriff", "speed:110", "hit-points:100", "experience:30", 
            "blow:HIT:HURT:2d5", "blow:BITE:HURT:2d5", "flags:ANIMAL|BASH_DOOR", 
            "desc:A strange hybrid of eagle and horse.", "depth:11", "\n"
        ]
        monsters = self.parser.read_monsters("monster.txt")
        self.assertEqual(len(monsters), 1)
        self.assertEqual(monsters[0].name, "hippogriff")
        self.assertEqual(monsters[0].speed, 110)
        self.assertEqual(monsters[0].hit_points, 100)
        self.assertEqual(monsters[0].experience, 30)
        
    @patch("os.path.exists")
    def test_file_not_found(self, mock_exists):
        mock_exists.return_value = False
        with self.assertRaises(FileNotFoundError):
            MonsterFileParser(self.gamedata_path)
    
    def test_get_monsters(self):
        self.assertEqual(self.parser.get_monsters(), self.parser.monsters)
    
    def test_get_blow_methods(self):
        self.assertEqual(self.parser.get_blow_methods(), self.parser.blow_methods)
    
    def test_get_blow_effects(self):
        self.assertEqual(self.parser.get_blow_effects(), self.parser.blow_effects)

class TestMonsterFileValidator(unittest.TestCase):
    
    def setUp(self):        
        self.monsters = [
            Monster(
                name="hippogriff", 
                speed=110, hit_points=100, experience=30, 
                    blows=[{"method": "HIT", "effect": "HURT", "damage": "2d5"}], 
                    flags={"ANIMAL", "BASH_DOOR"}, description="A strange hybrid of eagle and horse.", depth=11)
        ]
        self.blow_methods = {"HIT", "BITE", "TOUCH"}
        self.blow_effects = {"HURT", "EXP_40"}
        
        self.validator = MonsterFileValidator(self.monsters, self.blow_methods, self.blow_effects)

    
    def test_validate_monster_invalid_name(self):
        invalid_monster = Monster(name="", speed=110, hit_points=100, experience=30, 
                                  blows=[{"method": "HIT", "effect": "HURT", "damage": "2d5"}], 
                                  flags={"ANIMAL", "BASH_DOOR"}, description="A strange hybrid of eagle and horse.", depth=11)
        result = self.validator.validate_monster(invalid_monster)
        self.assertFalse(result)
    
    def test_validate_monster_invalid_speed(self):
        invalid_monster = Monster(name="hippogriff", speed=-1, hit_points=100, experience=30, 
                                  blows=[{"method": "HIT", "effect": "HURT", "damage": "2d5"}], 
                                  flags={"ANIMAL", "BASH_DOOR"}, description="A strange hybrid of eagle and horse.", depth=11)
        result = self.validator.validate_monster(invalid_monster)
        self.assertFalse(result)
    
    def test_validate_monster_invalid_hit_points(self):
        invalid_monster = Monster(name="hippogriff", speed=110, hit_points=-100, experience=30, 
                                  blows=[{"method": "HIT", "effect": "HURT", "damage": "2d5"}], 
                                  flags={"ANIMAL", "BASH_DOOR"}, description="A strange hybrid of eagle and horse.", depth=11)
        result = self.validator.validate_monster(invalid_monster)
        self.assertFalse(result)
    
    def test_validate_blows_valid(self):
        valid_blows = [{"method": "HIT", "effect": "HURT", "damage": "2d5"}]
        result = self.validator.validate_blows(valid_blows)
        self.assertTrue(result)
    
    def test_validate_blows_invalid_method(self):
        invalid_blows = [{"method": "INVALID", "effect": "HURT", "damage": "2d5"}]
        result = self.validator.validate_blows(invalid_blows)
        self.assertFalse(result)
    
    def test_validate_blows_invalid_damage(self):
        invalid_blows = [{"method": "HIT", "effect": "HURT", "damage": "invalid"}]
        result = self.validator.validate_blows(invalid_blows)
        self.assertFalse(result)
    

if __name__ == '__main__':
    unittest.main()

