# Master of Jokes – Status Report Enhancement

## Objective

The objective of this modification is to enhance the existing Master of Jokes (MoJ) application by adding a Status Report page. This page will be built using React and will display system-level statistics including the total number of registered users and total number of jokes in the database. The report will be powered by a new API endpoint in the Flask backend.

---

## System Changes

### 1. Flask Backend

- Create a new API endpoint: `/api/status`
- Return total user and joke counts as JSON
- Implement the endpoint in a new module (`api.py`)
- Register the API blueprint in the main app
- Enable CORS for external access from the React frontend

### 2. React Frontend

- Initialize a new React project
- Create two components:
  - One for displaying total users
  - One for displaying total jokes
- Use Axios and async/await to fetch data from the API
- Apply custom CSS to match the MoJ application design

---

## Integration Plan

- React will run on port `3000`, Flask backend on port `5000`
- The Status Report will be publicly accessible without authentication
- API data will be fetched in real-time via HTTP GET request

---

## Summary

This enhancement adds a simple, modular React-based status dashboard that connects to the Flask backend through a RESTful API. It improves visibility into application metrics and prepares the system for future frontend expansion.
