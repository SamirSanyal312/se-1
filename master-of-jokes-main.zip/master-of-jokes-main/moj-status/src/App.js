import React from 'react';
import './style.css';
import UserCount from './components/UserCount';
import JokeCount from './components/JokeCount';

function App() {
  return (
    <div className="container">
      <div className="logo" style={{ fontSize: '3rem' }}>🤡</div>
      <div className="title">Master of Jokes</div>
      <div className="subtitle">Status Report</div>

      <div className="stat-box"><UserCount /></div>
      <div className="stat-box"><JokeCount /></div>
    </div>
  );
}

export default App;
