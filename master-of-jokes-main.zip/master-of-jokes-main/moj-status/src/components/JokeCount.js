import React, { useEffect, useState } from 'react';
import axios from 'axios';

const JokeCount = () => {
  const [count, setCount] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:5000/api/status')
      .then(res => setCount(res.data.joke_count))
      .catch(err => console.error(err));
  }, []);

  return <div>Total Jokes Available: {count ?? 'Loading...'}</div>;
};

export default JokeCount;
