from flask import Blueprint, jsonify
from moj.db import get_db

bp = Blueprint('api', __name__, url_prefix='/api')

from flask_cors import CORS
CORS(bp)

@bp.route('/status', methods=['GET'])
def get_status():
    db = get_db()
    user_count = db.execute("SELECT COUNT(*) FROM user").fetchone()[0]
    joke_count = db.execute("SELECT COUNT(*) FROM joke").fetchone()[0]
    return jsonify({
        'user_count': user_count,
        'joke_count': joke_count
    })
