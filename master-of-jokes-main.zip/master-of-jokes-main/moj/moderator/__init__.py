# optional: you can leave it empty or do
from .routes import bp
